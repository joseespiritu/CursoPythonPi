def potencia(base,exponente):
    print("El resultado de la multiplicacion es: ",base**exponente)
    
def redondear(numero):
    print("El resultado de la multiplicacion es: ",round(numero))