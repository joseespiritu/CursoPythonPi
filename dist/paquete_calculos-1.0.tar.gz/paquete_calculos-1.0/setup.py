# ARCHIVO QUE DESCRIBE LA CONFIGURACION DEL PAQUETE DISTRIBUIBLE
# UNA VEZ CREADO EL ARCHIVO ES NECESARIO IR A LA CONSOLA
# MOVERSE A LA CARPETA DONDE SE CREO EL SETUP
# SE EJECUTA EL COMANDO python setup.py sdist

from setuptools import setup

setup(
    name="paquete_calculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Juan",
    author_email="jose@mail.com",
    url="www.jose.com",
    packages=["paquete_calculos","paquete_calculos.redondeo_potencia"]
    )